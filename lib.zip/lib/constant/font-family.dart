class FontFamily {
  static String primary = "Poxima-nova";
  static String primary1 = "Poppins-bold";
}
class AppImage {
  static String splash = "assets/image_png/Splash.png";
  static String AUTHAPPIMAGE = "assets/images/png/auth-image-png.png";
  static String FACEBOOK = "assets/images/svg/facebook.svg";
  static String GOOGLE = "assets/images/svg/google.svg";
  static String LOCATION = "assets/images/svg/location.svg";
  static String SLIDE = "assets/images/png/slide.png";

}

